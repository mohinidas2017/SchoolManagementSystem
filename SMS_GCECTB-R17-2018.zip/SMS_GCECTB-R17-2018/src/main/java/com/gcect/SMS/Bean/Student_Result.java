package com.gcect.SMS.Bean;

public class Student_Result {
	private String roll_number;
	private String full_name;
	private double ecommerce;
	private double industrial_management;
	private double cyberlaw;
	private double cryptography;
	private double grand_total;
	public String getRoll_number() {
		return roll_number;
	}
	public void setRoll_number(String roll_number) {
		this.roll_number = roll_number;
	}
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
	public double getEcommerce() {
		return ecommerce;
	}
	public void setEcommerce(double ecommerce) {
		this.ecommerce = ecommerce;
	}
	public double getIndustrial_management() {
		return industrial_management;
	}
	public void setIndustrial_management(double industrial_management) {
		this.industrial_management = industrial_management;
	}
	public double getCyberlaw() {
		return cyberlaw;
	}
	public void setCyberlaw(double cyberlaw) {
		this.cyberlaw = cyberlaw;
	}
	public double getCryptography() {
		return cryptography;
	}
	public void setCryptography(double cryptography) {
		this.cryptography = cryptography;
	}
	public double getGrand_total() {
		return grand_total;
	}
	public void setGrand_total(double grand_total) {
		this.grand_total = grand_total;
	}
	

}
